﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Assign
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void button1_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image == null)
            {
                pictureBox1.Image = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            }

            Pen pen = new Pen(Color.Red, 2);
            var graphics = Graphics.FromImage(pictureBox1.Image);
            graphics.Clear(Color.White);



            string x = textBox1.Text;
            string[] b = new string[5];
            int i = 0;
            x.ToLower();
            foreach (var a in x.Split(' '))
            {
                b[i] = a;
                i++;
            }

            string y = textBox2.Text;
            string[] w = new string[5];
            int j = 0;
            y.ToLower();
            foreach (var a in y.Split(' '))
            {
                w[j] = a;
                j++;
            }

            

            if (b[0].Equals("circle"))
            {
                if (b[1] is null)
                {
                    graphics.DrawEllipse(pen, 0, 0, 40, 40);
                }
                else
                {
                    graphics.DrawEllipse(pen, 0, 0, float.Parse(b[1]), float.Parse(b[1]));
                }
            }
            else if (b[0].Equals("square"))
            {
                if (b[1] is null && b[2] is null)
                {
                    graphics.DrawRectangle(pen, 0, 0, 90, 90);
                }
                else
                {
                    graphics.DrawRectangle(pen, 0, 0, float.Parse(b[1]), float.Parse(b[2]));
                }
            }
            else if (b[0].Equals("triangle"))
            {
                Point[] points = { new Point(10, 100), new Point(120, 10), new Point(200, 100) };
                graphics.DrawPolygon(pen, points);
            }
            else if (b[0].Equals("clear"))
            {
                graphics.Clear(Color.White);
            }
            else
            {
                if (b[0] is null && w[0] is null)
                {
                    textBox3.Text = "Enter Correct Command";
                }
            }




            if (w[0].Equals("circle"))
            {
                if (w[1] is null)
                {
                    graphics.DrawEllipse(pen, 0, 0, 40, 40);
                }
                else
                {
                    graphics.DrawEllipse(pen, 0, 0, float.Parse(w[1]), float.Parse(w[1]));
                }
            }
            else if (w[0].Equals("square"))
            {
                if (w[1] is null && w[2] is null)
                {
                    graphics.DrawRectangle(pen, 0, 0, 90, 90);
                }
                else
                {
                    graphics.DrawRectangle(pen, 0, 0, float.Parse(w[1]), float.Parse(w[2]));
                }
            }
            else if (w[0].Equals("triangle"))
            {
                Point[] points = { new Point(10, 100), new Point(120, 10), new Point(200, 100) };
                graphics.DrawPolygon(pen, points);
            }
            else if (w[0].Equals("clear"))
            {
                graphics.Clear(Color.White);
            }
            else
            {
                if (b[0] is null && w[0] is null)
                {
                    textBox3.Text = "Enter Correct Command";
                }

            }


            pictureBox1.Refresh();
        }


        public void Form1_Load(object sender, EventArgs e)
        {

        }

        public void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        public void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        public void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
